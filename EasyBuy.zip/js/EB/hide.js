//商品分类隐藏显示
	$(".nav").hover(function(){
		console.log($(".leftNav").css("display"));
		if($(".leftNav").css("display")=="none"){
			$(".leftNav").css("display",'block');
		}else if($(".leftNav").css("display")=="block"){
			$(".leftNav").css("display",'none');
		}
	})