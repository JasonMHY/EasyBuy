 $(".soubg").load("header.html",function(){
	 var user = JSON.parse(sessionStorage.getItem("user"));
	  if(user!=null){//如果登陆就把class html替换掉  默认未登录
	 	$(".fr").eq(0).html('<span class="fl"><span style="color:#ff4e00;">'
		+user.userName+
		'</span>&nbsp;<a href="#">我的订单</a>&nbsp;|&nbsp;</span><span <a href="#">后台管理</a>&nbsp;'+
		'</span><a href="#" id="loggedOut" style="color:#ff4e00;">退出</a>&nbsp;&nbsp;</span>');
	 }
	$("#loggedOut").click(function(){//退出登陆
		sessionStorage.removeItem("user");
		sessionStorage.removeItem("cart");
		location.href="login.html";
	})
 });


