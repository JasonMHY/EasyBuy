$(function() {
	shopcars();
	var hide = 0;
	var user = JSON.parse(sessionStorage.getItem("user"));
	console.log(user);
	/* if (userName == null) { //访问index页面，name为空跳转login页面
		location.href = "login.html";
	} */
	//购物车  判断是否登陆显示
	if (user != null) {
		$(".un_login").html("我的购物车");
		$(".price_a").html('<a>去结算</a>');
	}
	fun();
})

//点击确认订单-----------------------------------------------------------------------------------------------------------------
function settlement3() {
	var userAddress = $("input[type='radio']:checked").val();
	if (userAddress != null) {
		var user = JSON.parse(sessionStorage.getItem("user"));
		var list = JSON.parse(sessionStorage.getItem("cart"));
		var price = 0;
		var map = {}
		var detail;
		var array = [];
		for (var i = 0; i < list.length; i++) {
			price = price + list[i].price * list[i].num;
			detail = {};
			detail['productId'] = list[i].id;
			detail['quantity'] = list[i].num;
			detail['cost'] = list[i].price * list[i].num;
			array.push(detail);
		}
		serialNumber = getCode();
		var order = {};
		order['userId'] = user.id;
		order['loginName'] = user.loginName;
		order['userAddress'] = userAddress;
		order['cost'] = price;
		order['serialNumber'] = serialNumber;
		map["order"] = order;
		map["detail"] = array;
		console.log(map);

		$.ajax({
			url: "http://localhost:8080/AddOrder",
			type: "post",
			datatype: "json",
			contentType: 'application/json;charset=utf-8',
			async: false,
			data: JSON.stringify(map),
			success: function(d) {
				console.log(d);
				var text = '<div class="content mar_20">' +
					'<img src="/WebRoot/statics/images/img3.jpg">' +
					'</div>' +
					'<div class="content mar_20">' +
					'<!--Begin 银行卡支付 Begin -->' +
					'<div class="warning">' +
					'<table border="0" style="width:1000px; text-align:center;" cellspacing="0" cellpadding="0">' +
					'<tbody><tr height="35">' +
					'<td style="font-size:18px;">' +
					'感谢您在本店购物！您的订单已提交成功，请记住您的订单号: <font color="#ff4e00">'+d.data.serialNumber+'</font>' +
					'</td>' +
					'</tr>' +
					'<tr>' +
					'<td style="font-size:14px; font-family:\'宋体 \'; padding:10px 0 20px 0; border-bottom:1px solid #b6b6b6;">' +
					'您选定的配送方式为: <font color="#ff4e00">申通快递</font>； &nbsp; &nbsp;您选定的支付方式为: <font color="#ff4e00">支付宝</font>； &nbsp; &nbsp;您的应付款金额为: <font color="#ff4e00">￥'+d.data.cost+'</font>' +
					'</td>' +
					'</tr>' +
					'<tr>' +
					'<td style="font-size:14px; font-family:\'宋体 \'; padding:10px 0 20px 0; border-bottom:1px solid #b6b6b6; ">' +
					'<iframe SRC="http://pay.blogs.ink/pay2.php?money='+d.data.cost+'&name=易买网商品购买" style="height: 513px;width: 360px;padding:0;"></iframe> '+
					'</td>' +
					'</tr>' +
					'<tr>' +
					'<td style="padding:20px 0 30px 0; font-family:\'宋体 \';">' +
					'收件人信息: '+d.data.loginName+' 地址: '+d.data.userAddress+'； <br>' +
					'</td>' +
					'</tr>' +
					'<tr>' +
					'<td>' +
					'<a href="/WebRoot/Home?action=index">首页</a> &nbsp; &nbsp; <a href="/WebRoot/Home?action=index">用户中心</a>' +
					'</td>' +
					'</tr>' +
					'</tbody></table>' +
					
					'</div>' +
					'</div>';
					$("#settlement").html(text);
					sessionStorage.removeItem("cart");
					shopcars();
			}
		})

	} else {
		jAlert('提示', '请选择地址', '确定');
	}
}

//map转JSON
function MapTOJson(map) {
	var str = '{';
	var i = 1;
	for (var key in map) {
		if (i == Object.keys(map).length) {
			str += '"' + key + '":"' + map[key] + '"';
		} else {
			str += '"' + key + '":"' + map[key] + '",';
		}
		i++;
	}
	str += '}';
	return str;
}
//订单编号
function getCode() {
	var all = "ZXCVBNMASDFGHJKLQWERTYUIOP0123456789";
	var b = "";
	for (var i = 0; i < 32; i++) {
		var index = Math.floor(Math.random() * 36);
		b += all.charAt(index);
	}
	return b;
};
//点击确认结算-----------------------------------------------------------------------------------------------------------------
function settlement2() {
	var list = JSON.parse(sessionStorage.getItem("cart")); //查询看购物车商品
	var shop = '';
	var price = 0;
	for (var i = 0; i < list.length; i++) {
		shop = shop + '<tr>' +
			'<td>' +
			'<div class="c_s_img">' +
			'<img src="http://localhost:8080/images/' + list[i].fileName + '" width="73" height="73">' +
			'</div>' +
			list[i].name +
			'</td>' +
			'<td align="center">' + list[i].num + '</td>' +
			'<td align="center" style="color:#ff4e00;">￥' + list[i].price * list[i].num + '</td>' +
			'</tr>';
		price = price + list[i].price * list[i].num;
	}


	var user = JSON.parse(sessionStorage.getItem("user"));
	var address = '';
	$.ajax({
		url: "http://localhost:8080/findId",
		datatype: "json",
		async: false,
		data: {
			id: user.id
		},
		success: function(d) {
			for (var i = 0; i < d.data.length; i++) {
				address = address + '<tr>' +
					'<td class="p_td" width="160">' +
					d.data[i].remark +
					'<input type="radio" name="selectAddress" value="' + d.data[i].id + '">' +
					'</td>' +
					'<td>' +
					d.data[i].address +
					'</td>' +
					'</tr>';
			}
		}
	})

	var text = '<div class="content mar_20">' +
		'<img src="images/img2.jpg">' +
		'</div>' +
		'<div class="content mar_20">' +
		'<div class="two_bg">' +
		'<div class="two_t">' +
		'<span class="fr"><a href="javascript:void(0);" onclick="settlement1();">修改</a></span>商品列表' +
		'</div>' +
		'<table border="0" class="car_tab" style="width:1110px;" cellspacing="0" cellpadding="0">' +
		'<tbody>' +
		'<tr>' +
		'<td class="car_th" width="550">商品名称</td>' +
		'<td class="car_th" width="150">购买数量</td>' +
		'<td class="car_th" width="130">小计</td>' +
		'</tr>' +
		shop +
		'</tbody>' +
		'</table>' +
		'<div class="two_t">' +
		'<span class="fr"></span>收货人信息' +
		'</div>' +
		'<table border="0" class="peo_tab" style="width:1110px;" cellspacing="0" cellpadding="0">' +
		'<tbody>' +
		'<tr>' +
		'<td class="p_td" width="160">用户名称</td>' +
		'<td width="395">' + user.userName + '</td>' +
		'<td class="p_td">登录名称</td>' +
		'<td>' + user.loginName + '</td>' +
		'</tr>' +
		'<tr>' +
		'<td class="p_td">手机</td>' +
		'<td>' + user.mobile + '</td>' +
		'<td class="p_td" width="160">电子邮件</td>' +
		'<td width="395">' + user.email + '</td>' +
		'</tr>' +
		'</tbody>' +
		'</table>' +
		'<div class="two_t">' +
		'<span class="fr"></span>选择地址' +
		'</div>' +
		'<table border="0" class="peo_tab" style="width:1110px;" cellspacing="0" cellpadding="0">' +
		'<tbody>' +
		address +
		'<tr>' +
		'<td class="p_td" width="160">' +
		'新地址<input type="radio" name="selectAddress" value="-1">' +
		'</td>' +
		'<td>' +
		'地址&nbsp;<input type="text" value="" name="address" class="add_ipt">&nbsp;' +
		'备注&nbsp;<input type="text" value="" name="remark" class="add_ipt">' +
		'</td>' +
		'</tr>' +
		'</tbody>' +
		'</table>' +
		'<table border="0" style="width:900px; margin-top:20px;" cellspacing="0" cellpadding="0">' +
		'<tbody>' +
		'<tr height="70">' +
		'<td align="right">' +
		'<b style="font-size:14px;">应付款金额：<span style="font-size:22px; color:#ff4e00;">￥' + price + '</span></b>' +
		'</td>' +
		'</tr>' +
		'<tr height="70">' +
		'<td align="right"><a href="javascript:void(0);" onclick="settlement3();"><img src="images/btn_sure.gif"></a></td>' +
		'</tr>' +
		'</tbody>' +
		'</table>' +
		'</div>' +
		'</div>';
	$("#settlement").html(text);

}

//结算
function Settlement() {
	var list = JSON.parse(sessionStorage.getItem("cart")); //查询看购物车商品
	$(".leftNav").css("display", 'none');
	$(".i_bg_r").html("");
	$("#settlement").html("");
	var tr = "";
	var price = 0;
	var jiesuan = "";
	if (list!= null) {
		for (var i = 0; i < list.length; i++) {
			tr = tr + '<tr>' +
				'<td>' +
				'<div class="c_s_img">' +
				'<a href="/WebRoot/Product?action=queryProductDeatil&amp;id=743"><img src="http://localhost:8080/images/' + list[i]
				.fileName + '"' +
				'width="73" height="73"></a>' +
				'</div>' +
				'' + list[i].name + '' +
				'</td>' +
				'<td align="center" style="color:#ff4e00;">￥' + list[i].price + '</td>' +
				'<td align="center">' +
				'<div class="c_num">' +
				'<input type="button" value="" onclick="subQuantity(this,' + list[i].id + ');" class="car_btn_1">' +
				'<input type="text" value="' + list[i].num + '" name="' + list[i].id + '" class="car_ipt">' +
				'<input type="button" value="" onclick="addQuantity(this,' + list[i].id + ');" class="car_btn_2">' +
				'</div>' +
				'</td>' +
				'<td align="center" style="color:#ff4e00;">￥' + list[i].price * list[i].num + '</td>' +
				'<td align="center"><a href="javascript:void(0);" onclick="removeCart(' + list[i].id + ');">删除</a></td>' +
				'</tr>';
			price = price + list[i].price * list[i].num;
		}
		jiesuan = '<a href="javascript:void(0);" onclick="settlement2();"><img src="images/buy2.gif"></a>';
	}
	$("#settlement").html('<div id="settlement">' +
		'<div class="content mar_20">' +
		'<img src="images/img1.jpg">' +
		'</div>' +
		'<!--Begin 第一步：查看购物车 Begin -->' +
		'<div class="content mar_20">' +
		'<table border="0" class="car_tab" style="width:1200px; margin-bottom:50px;" cellspacing="0" cellpadding="0">' +
		'<tbody>' +
		'<tr>' +
		'<td class="car_th" width="200">商品名称</td>' +
		'<td class="car_th" width="150">单价</td>' +
		'<td class="car_th" width="150">购买数量</td>' +
		'<td class="car_th" width="130">小计</td>' +
		'<td class="car_th" width="150">操作</td>' +
		'</tr>' +
		tr +
		'<tr height="70">' +
		'<td colspan="6" style="font-family:\'Microsoft YaHei\'; border-bottom:0;">' +
		'<span class="fr">商品总价：<b style="font-size:22px; color:#ff4e00;">￥' + price + '</b></span>' +
		'</td>' +
		'</tr>' +
		'<tr valign="top" height="150">' +
		'<td colspan="6" align="right">' +
		'<a href="index.html"><img src="images/buy1.gif"></a>&nbsp;&nbsp;' +
		jiesuan +
		'</td>' +
		'</tr>' +
		'</tbody>' +
		'</table>' +
		'</div>' +
		'</div>');
}
//结算页面删除
function removeCart(id) {
	deletePurchased(id); //删除购物商品
	Settlement(); //跳转结算页面

}
//减少商品数量
function subQuantity(sub, id) {
	$(sub).next().val(parseInt($(sub).next().val()) - 1);
	Quantity(sub, id, $(sub).next().val());
}
//增加商品数量
function addQuantity(add, id) {
	$(add).prev().val(parseInt($(add).prev().val()) + 1);
	Quantity(add, id, $(add).prev().val());
}

//修改商品数量调用
function Quantity(th, id, num) {
	var list = JSON.parse(sessionStorage.getItem("cart")); //查询看购物车商品
	var array = new Array(); //定义一个新数组
	if (list != null) {
		for (var i = 0; i < list.length; i++) {
			var map = {};
			if (list[i].id == id) { //判断是否是要修改的商品
				map["id"] = list[i].id;
				map["stock"] = list[i].stock;
				map["name"] = list[i].name;
				map["price"] = list[i].price;
				map["fileName"] = list[i].fileName;
				if (num <= parseInt(list[i].stock) && num > 0) {
					map["num"] = num; //购买的num
				} else {
					map["num"] = list[i].num; //大于库存小于等于0不做修改
					$(th).prev().val(list[i].num);
					jAlert('提示', '数据修改异常，请重试', '确定');
				}
				array.push(map);
			} else { //循环以前订单加入新数组
				map["id"] = list[i].id;
				map["stock"] = list[i].stock;
				map["name"] = list[i].name;
				map["price"] = list[i].price;
				map["fileName"] = list[i].fileName;
				map["num"] = list[i].num;
				array.push(map);
			}
		}
		sessionStorage.setItem("cart", JSON.stringify(array)); //转字符串储存
		shopcars();
		Settlement();
	} else {
		jAlert('提示', '数据修改异常，请退出重试', '确定');
	}
}
//购物车
function shopping(id, num) {
	/* num!=undefined?num:$("input[name='quantity']").val(); */
	if (num == undefined) {
		num = $("input[name='quantity']").val();
	}

	$.ajax({
		url: "http://localhost:8080/shopping",
		datatype: "json",
		async: false,
		data: {
			id: id
		},
		success: function(d) {
			if (num <= d[0].stock) { //加购数量小于库存执行加购
				purchased(d, num);
				jAlert('提示', '加入购物车成功', '确定');
			} else {
				jAlert('提示', '商品库存不足', '确定');
			}
			shopcars();

		}
	})

	/* sessionStorage.removeItem("cart"); */

}

//删除加购
function deletePurchased(id) {
	var list = JSON.parse(sessionStorage.getItem("cart")); //查询看购物车商品
	var array = new Array(); //定义一个新数组
	if (list != null) {
		for (var i = 0; i < list.length; i++) {
			var map = {};
			if (list[i].id != id) { //判断是否是删除物品
				map["id"] = list[i].id;
				map["stock"] = list[i].stock;
				map["name"] = list[i].name;
				map["price"] = list[i].price;
				map["fileName"] = list[i].fileName;
				map["num"] = list[i].num;
				array.push(map);
			}
		}
		sessionStorage.setItem("cart", JSON.stringify(array)); //转字符串储存
		shopcars();
	} else {
		jAlert('提示', '数据出现异常，请退出重试', '确定');
	}

}

//加购
function purchased(d, num) {
	var list = JSON.parse(sessionStorage.getItem("cart")); //查询看购物车商品
	var array = new Array(); //定义一个新数组
	var bool = false; //判断是否一件商品
	if (list != null) { //购物车商品不为空执行
		for (var i = 0; i < list.length; i++) {
			var map = {};
			if (list[i].id == d[0].id) { //判断添购物商品是否购买过

				map["id"] = list[i].id;
				map["stock"] = list[i].stock;
				map["name"] = list[i].name;
				map["price"] = list[i].price;
				map["fileName"] = list[i].fileName;
				map["num"] = (parseInt(list[i].num) + parseInt(num)); //购买过num+num
				array.push(map);
				bool = true;
			} else { //循环以前订单加入新数组
				map["id"] = list[i].id;
				map["stock"] = list[i].stock;
				map["name"] = list[i].name;
				map["price"] = list[i].price;
				map["fileName"] = list[i].fileName;
				map["num"] = list[i].num;
				array.push(map);
			}
		}
		if (!bool) { //判断购买过不执行
			var map = {}; //定义一个新数组
			map["id"] = d[0].id;
			map["stock"] = d[0].stock;
			map["name"] = d[0].name;
			map["price"] = d[0].price;
			map["fileName"] = d[0].fileName;
			map["num"] = num;
			array.push(map);
			console.log(num);
		}
	} else { //购物车为空直接添加商品
		console.log(d);
		var map = {}; //定义一个新数组
		map["id"] = d[0].id;
		map["stock"] = d[0].stock;
		map["name"] = d[0].name;
		map["price"] = d[0].price;
		map["fileName"] = d[0].fileName;
		map["num"] = num;
		array.push(map);
		console.log(num);
	}
	sessionStorage.setItem("cart", JSON.stringify(array)); //转字符串储存
}


//购物车显示商品信息
function shopcars() {
	var list = JSON.parse(sessionStorage.getItem("cart")); //查询看购物车商品
	$(".cars").html("");
	var price = 0;
	$(".price_sum span").html(price);
	$(".car_t span").html("空");
	if (list != null) {
		for (var i = 0; i < list.length; i++) {
			$(".cars").append('<li>' +
				'<div class="img"><a href="javascript:void(0);" onclick="Details(' + list[i].id +
				');"><img src="http://localhost:8080/images/' + list[i].fileName + '" width="58" height="58"></a></div>' +
				'<div class="name"><a  href="javascript:void(0);" onclick="Details(' + list[i].id + ');">' + list[i].name +
				'</a></div>' +
				'<div class="price"><font color="#ff4e00">￥' + list[i].price + '</font> X' + list[i].num + '</div>' +
				'</li>');
			price = price + list[i].price * list[i].num;
			$(".price_sum span").html(price);
			$(".car_t span").html(list.length);
		}
	}
}



//提取查询  分类查询商品
function search(d) {
	$(".leftNav").css("display", 'none');
	$(".i_bg_r").html("");
	$("#settlement").html("");
	$.getScript("js/EB/hide.js");
	var text = '<div class="content mar_20">' +
		'<div id="favoriteList">' +
		'<div class="l_history">' +
		'<div class="fav_t">我的收藏</div>' +
		'</div>' +
		'</div>' +
		'<div class="l_list">' +
		'<div class="list_t">' +
		'<span class="fr">共发现' + d.data.length + '件</span>' +
		'</div>' +
		'<div class="list_c">' +
		'<ul class="cate_list">';
	for (var i = 0; i < d.data.length; i++) {
		text = text + '<li>' +
			'<div class="img">' +
			'<a href="javascript:void(0);" onclick="Details(' + d.data[i].id + ');">' +
			'<img src="http://localhost:8080/images/' + d.data[i].fileName + '" width="210" height="185"/>' +
			'</a>' +
			'</div>' +
			'<div class="price">' +
			'<font>￥<span>' + d.data[i].price + '</span></font>' +
			'</div>' +
			'<div class="name"><a href="javascript:void(0);" onclick="Details(' + d.data[i].id + ');">' + d.data[i].name +
			'</a></div>' +
			'<div class="carbg">' +
			'<a href="javascript:void(0);" class="ss" onclick="addFavorite(' + 733 + ')">收藏</a>' +
			'<a href="javascript:void(0);" class="j_car" onclick="shopping(' + d.data[i].id + ',1);">加入购物车</a>' +
			'</div>' +
			'</li>';
	}
	text = text + '</ul></div></div></div></div>';
	$(".i_bg_r").html(text);
}




//三级导航菜单查询
function threeFindShop(id) {
	$.ajax({
		url: "http://localhost:8080/threeFindShop",
		datatype: "json",
		async: false,
		data: {
			categoryLevel3Id: id
		},
		success: function(d) {
			search(d);
		}
	})
}
//二级导航菜单查询
function twoFindShop(id) {
	$.ajax({
		url: "http://localhost:8080/twoFindShop",
		datatype: "json",
		async: false,
		data: {
			categoryLevel2Id: id
		},
		success: function(d) {
			search(d);
		}
	})
}


//点击分类显示商品  
function shopBlurb(id) {
	$.ajax({
		url: "http://localhost:8080/Blurb",
		datatype: "json",
		async: false,
		data: {
			categoryLevel1Id: id
		},
		success: function(d) {
			search(d);
		}
	})
}

//商品详情
function Details(id) {
	$.ajax({
		url: "http://localhost:8080/Details",
		datatype: "json",
		async: false,
		data: {
			id: id
		},
		success: function(d) {
			publicDetails(d);
		}
	})

}
//提取商品详情
function publicDetails(d) {
	$(".leftNav").css("display", 'none');
	$(".i_bg_r").html("");
	$("#settlement").html("");
	$.getScript("js/EB/hide.js");
	var text = '<div class="postion">' +
		'</div>' +
		'<div class="content">' +
		'<div id="tsShopContainer">' +
		' <div id="tsImgS">' +
		'<a href="http://localhost:8080/images/' + d.data[0].fileName + '" title="Images" class="MagicZoom" id="MagicZoom">' +
		'   <img src="http://localhost:8080/images/' + d.data[0].fileName + '" width="390" height="390"/>' +
		'  </a>' +
		' </div>' +
		' </div>' +
		' <div class="pro_des">' +
		' <div class="des_name">' +
		' <input type="hidden" value="743"  name="entityId" class="n_ipt"/>' +
		' <p>' + d.data[0].name + '</p>' +
		' “开业巨惠，北京专柜直供”，不光低价，“真”才靠谱！' +
		'</div>' +
		'<div class="des_price">' +
		' 本店价格：<b>￥' + d.data[0].price + '</b><br/>' +
		' </div>' +
		'<div class="des_repertory">' +
		'  库存：<b>' + d.data[0].stock + '</b><br/>' +
		' </div>' +
		' <div class="des_choice">' +
		'   <span class="fl">型号选择：</span>' +
		' <ul>' +
		'   <li class="checked">30ml' +
		'   <div class="ch_img"></div>' +
		' </li>' +
		'<li>50ml' +
		' <div class="ch_img"></div>' +
		'</li>' +
		'<li>100ml' +
		'<div class="ch_img"></div>' +
		'</li>' +
		'</ul>' +
		'</div>' +
		'<div class="des_choice">' +
		' <span class="fl">颜色选择：</span>' +
		' <ul>' +
		' <li>红色' +
		' <div class="ch_img"></div>' +
		'</li>' +
		'<li class="checked">白色' +
		'<div class="ch_img"></div>' +
		'</li>' +
		'<li>黑色' +
		'<div class="ch_img"></div>' +
		'</li>' +
		'</ul>' +
		'</div>' +
		'<br>' +
		'<br>' +
		'<div class="des_join">' +
		'<div class="j_nums">' +
		' <input type="text"   value="1"  name="quantity" class="n_ipt"/>' +
		' <input type="button" value="" onclick="addUpdate(jq(this));" class="n_btn_1"/>' +
		'<input type="button" value="" onclick="jianUpdate(jq(this));" class="n_btn_2"/>' +
		'<input type="hidden" name="productStock" value="1000">' +
		' </div>' +
		'<span class="fl">' +
		'  <img src="images/j_car.png" onclick="shopping(' + d.data[0].id + ');"/>' +
		'</span>' +
		' </div>' +
		'  </div>' +
		'</div>' +
		'<div class="content mar_20">' +
		'<div id="favoriteList">' +
		'  </div>' +
		' <div class="l_list">' +
		' <div class="des_border">' +
		'<div class="des_tit">' +
		'<ul>' +
		'<li class="current"><a href="#p_attribute">商品属性</a></li>' +
		'<li><a href="#p_details">商品详情</a></li>' +
		'</ul>' +
		'</div>' +
		'<div class="des_con" id="p_attribute">' +
		'<table border="0" align="center" style="width:100%; font-family:\'宋体 \'; margin:10px auto;"' +
		'cellspacing="0" cellpadding="0">' +
		'<tr>' +
		'<td>商品名称：' + d.data[0].name + '</td>' +
		'<td>商品价格：' + d.data[0].price + '</td>' +
		' <td>品牌： 迪奥（Dior）</td>' +
		'<td>上架时间：2015-09-06 09:19:09 </td>' +
		'</tr>' +
		'<tr>' +
		'<td>商品毛重：160.00g</td>' +
		'<td>商品产地：法国</td>' +
		'<td>香调：果香调香型：淡香水/香露EDT</td>' +
		'<td>&nbsp;</td>' +
		'</tr>' +
		'<tr>' +
		'<td>容量：1ml-15ml </td>' +
		'<td>类型：女士香水，Q版香水，组合套装</td>' +
		'<td>&nbsp;</td>' +
		'<td>&nbsp;</td>' +
		'</tr>' +
		'</table>' +
		'</div>' +
		'</div>' +
		'<div class="des_border" id="p_details">' +
		'<div class="des_t">商品详情</div>' +
		'<div class="des_con">' +
		'<table border="0" align="center" style="width:745px; font-size:14px; font-family:\'宋体\';" cellspacing="0" cellpadding="0">' +
		'<tr>' +
		'<td>' +
		'</td>' +
		'</tr>' +
		'</table>' +
		'<p align="center">' +
		'<img src="//localhost:8080/images/' + d.data[0].fileName + '" width="185" height="155">' +
		'</p>' +
		'</div>' +
		'</div>' +
		'</div>' +
		'</div>';
	$(".i_bg_r").html(text);
}


//加载页面
function fun() {
	//商品
	$.ajax({
		url: "http://localhost:8080/shop",
		datatype: "json",
		async: false,
		success: function(d) {
			var item = "";
			for (var i = 0; i < d.data.itemTitle.length; i++) {
				if (item == null) {
					item = '<div class="i_t mar_10"><span class="floor_num">' + (i + 1) + 'F</span><span class="fl">' + d.data.itemTitle[
						i].name + '</span></div>';
				} else {
					item = item + '<div class="i_t mar_10"><span class="floor_num">' + (i + 1) + 'F</span><span class="fl">' + d.data
						.itemTitle[i].name + '</span></div>';
				}
				var itemType = "";
				for (var k = 0; k < d.data.itemType[i].length; k++) {
					itemType = itemType + '<a href="#">' + d.data.itemType[i][k].name + '</a>';
				}

				item = item + '<div class="content"><div class="fresh_left"><div class="fre_ban"><div id="imgPlay1">' +
					'<ul class="imgs" id="actor1">' +
					'<li><a href="#"><img src="images/fre_r.jpg" width="211" height="286"/></a></li>' +
					'<li><a href="#"><img src="images/fre_r.jpg" width="211" height="286"/></a></li>' +
					'<li><a href="#"><img src="images/fre_r.jpg" width="211" height="286"/></a></li>' +
					'</ul>' +
					'<div class="prevf">上一张</div>' +
					'<div class="nextf">下一张</div>' +
					'</div>' +
					'</div>' +
					'<div class="fresh_txt">' +
					'<div class="fresh_txt_c">' +
					itemType +
					'</div>' +
					'</div>' +
					'</div>';

				var Blurb = "";
				for (var j = 0; j < d.data.Blurb[i].length; j++) {
					Blurb = Blurb + '<li>' +
						'<div class="name"><a href="#">' + d.data.Blurb[i][j].name + '</a></div>' +
						'<div class="price">' +
						'<font>￥<span>' + d.data.Blurb[i][j].price + '</span></font> &nbsp;' +
						'</div>' +
						'<div class="img">' +
						'<a  href="javascript:void(0);" onclick="Details(' + d.data.Blurb[i][j].id + ');">' +
						'<img src="http://localhost:8080/images/' + d.data.Blurb[i][j].fileName + '" width="185"  height="155"/>' +
						'</a>' +
						'</div>' +
						'</li>';
				}
				item = item + '<div class="fresh_mid"><ul>' + Blurb + '</ul></div><div class="fresh_right"><ul>' +
					'<li><a href="#"><img src="images/fre_b1.jpg" width="260" height="220"/></a></li>' +
					'<li><a href="#"><img src="images/fre_b2.jpg" width="260" height="220"/></a></li>' +
					'</ul>' +
					'</div>' +
					'</div>';
			}

			$("#shop").html(item);

		},
	})
	//商品分类 一级 二级 三级导航
	$.ajax({
		url: "http://localhost:8080/shopCategory",
		datatype: "json",
		async: false,
		success: function(d) {
			var item = "";
			for (var i = 0; i < d.data.itemTitle.length; i++) { //遍历获取一级导航菜单
				item = item + '<li>' +
					'<div class="fj">' +
					'<span class="n_img"><span></span>' +
					'</span>' +
					'<span class="fl">' + d.data.itemTitle[i].name + '</span>' +
					'</div>';
				var title = "";
				var text1 = "";
				for (var k = 0; k < d.data.subtitle[i].length; k++) { //遍历获取二级导航菜单
					title = '<a href="javascript:void(0);" onclick="twoFindShop(' + d.data.subtitle[i][k].id + ');">' + d.data.subtitle[
							i][k].name +
						'</a>';
					var text = "";
					for (var j = 0; j < d.data.text[i][k].length; j++) { //遍历获取三级导航菜单
						text = text + '<a href="javascript:void(0);" onclick="threeFindShop(' + d.data.text[i][k][j].id + ');">' + d
							.data.text[i][k]
							[j].name + '</a> |';
					}
					text1 = text1 + '<div class="zj_l_c"><h2> ' + title + ' </h2>' + text + '</div>';
				}
				item = item + '<div class="zj"><div class="zj_l">' + text1 + '</div></div></li>';
			}
			$(".leftNav ul").html(item);
		}
	})

	//商品分类 首页顶部导航
	$.ajax({
		url: "http://localhost:8080/itemTitle",
		datatype: "json",
		async: false,
		success: function(d) {
			for (var i = 0; i < d.data.length; i++) { //遍历获取导航
				$(".menu_r").append('<li><a href="javascript:void(0);" onclick="shopBlurb(' + d.data[i].id + ');">' + d.data[i]
					.name + '</a></li>');
			}
		}
	})



	//公告
	$.ajax({
		url: "http://localhost:8080/NewsFindAll",
		datatype: "json",
		async: false,
		success: function(d) {
			for (var i = 0; i < 5; i++) { //遍历获取导航
				$(".inews ul").append('<li><span>[ 公告 ]</span><a href="/WebRoot/admin/news?action=newsDeatil&id=531">' + d.data[
					i].title + '</a></li>');
			}
		}
	})

	//搜索商品
	$(".s_btn").click(function() {

		var name = $("input[name='keyWord']").val();
		$.ajax({
			url: "http://localhost:8080/findName",
			datatype: "json",
			async: false,
			data: {
				name: name
			},
			success: function(d) {
				search(d);

			}

		})
	})
	//点击结算
	$(".price_a").click(function() {
		Settlement();
	})
}
