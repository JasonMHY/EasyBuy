var user = JSON.parse(sessionStorage.getItem("user"));
//判断已登陆就跳转到index
if (user != null) {
	alert(user.userName + "已登录");
	location.href = "index.html";
}
//登陆
function login() {
	var loginName = $("#loginName").val();
	var password = hex_md5($("#password").val());
	$.get("http://localhost:8080/login", {
		loginName: loginName,
		password: password
	}, function(obj) {
		if (obj.code == 200) {
			sessionStorage.setItem("user", JSON.stringify(obj.data)); //转字符串储存
			location.href = "index.html";
		} else {
			alert("登陆失败");
		}
	}, "json")
}
